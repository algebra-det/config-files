return {
  {
    "ggandor/leap.nvim",
    config = function(_, opts)
      local leap = require("leap")
      for k, v in pairs(opts) do
        leap.opts[k] = v
      end
      leap.add_default_mappings(true)

      -- Remove default "s" mapping
      vim.keymap.del({ "n", "x", "o" }, "s")
    end,
    keys = {
      -- { "'", mode = { "n", "x", "o" }, desc = "Leap Forward to" },
    },
  },
}
