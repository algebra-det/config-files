return {
  { "copilot", enabled = false },
}
